function clickMenu(){
    if(itens.style.display == 'block'){
        itens.style.display = 'none'
    }else{
        itens.style.display = 'block'
    }   
}


function validarEmail() {
  var email = document.querySelector('input[name="email"]').value;
  if (validarEmailCompleto(email)) {
      alert("Obrigado pelo contato! Retornaremos assim que possível.");
  } else {
      alert("Email inválido, tente novamente.");
  }
}

function validarEmailCompleto(email) {
  var regexCompleta = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return regexCompleta.test(email);
}


$(document).ready(function () {
    $(".js-slider").slick({  
        dots:false,
        infinite: false,
        speed: 300,
        slidesToShow: 6,
        slidesToScroll: 1,
        responsive: [
            {
              breakpoint: 1024,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 3,
                infinite: true,
                dots: true
              }
            },
            {
              breakpoint: 600,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 2
              }
            },
            {
              breakpoint: 480,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
            }
            // You can unslick at a given breakpoint now by adding:
            // settings: "unslick"
            // instead of a settings object
          ]
        });
      });
